
const venom = require('venom-bot');
require('dotenv').config();
const axios = require('axios');

venom
  .create()
  .then((client) => start(client))
  .catch((error) => console.error(error));

function start(client) {
  client.onMessage(async (message) => {
    if (message.body && message.isGroupMsg === false) {
      try {
        await axios.post(process.env.N8N_WEBHOOK_URL, {
          from: message.from,
          body: message.body,
          name: message.sender?.pushname || "Sin nombre"
        });
      } catch (error) {
        console.error('Error al enviar al webhook:', error.message);
      }
    }
  });
}
