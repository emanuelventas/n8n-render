# 🤖 Bot WhatsApp + n8n para Emanuel

Este bot escucha mensajes de WhatsApp y los envía a un Webhook de n8n.

## 📌 Variables necesarias (Render > Environment Variables):

- SESSION = botEmanuelSession
- CLIENT_URL = https://n8n-render-1-mp3q.onrender.com
- WEBHOOK_URL = https://n8n-render-1-mp3q.onrender.com/webhook/8e82dffc-0e7c-40a2-b025-676ab1faa200
- SECRET_KEY = emanu3lKey2025
- NODE_ENV = production
- WHATSAPP_ENABLED = true
- AUTO_RESTART = true
- TZ = America/Bogota
- LANGUAGE = es
- LOG_LEVEL = info
- MAX_RETRIES = 3
- QR_RETRIES = 5
- SHOW_QR_IN_TERMINAL = true

## 🚀 Comandos en Render

- Build Command: `npm install`
- Start Command: `npm install && npm start`