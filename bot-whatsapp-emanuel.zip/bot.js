const { createBot } = require('@open-wa/wa-automate');
const axios = require('axios');
require('dotenv').config();

const start = async () => {
  const bot = await createBot({
    sessionId: process.env.SESSION,
    multiDevice: true,
    qrTimeout: 0,
    authTimeout: 0,
    blockCrashLogs: true,
    disableSpins: true,
    headless: true,
    useChrome: true,
    popup: false,
    restartOnCrash: start,
    logConsole: process.env.SHOW_QR_IN_TERMINAL === 'true',
  });

  bot.onMessage(async (message) => {
    if (message.body && message.from !== 'status@broadcast') {
      const nombreUsuario = message.pushname || "usuario";
      const data = {
        mensaje: message.body,
        nombreUsuario: nombreUsuario,
        numero: message.from,
        secret_key: process.env.SECRET_KEY
      };

      try {
        await axios.post(process.env.WEBHOOK_URL, data);
        console.log("📨 Mensaje enviado al Webhook con éxito.");
      } catch (error) {
        console.error("❌ Error al enviar al Webhook:", error.message);
      }
    }
  });
};

start();