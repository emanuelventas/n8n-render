
const venom = require('venom-bot');
const axios = require('axios');

venom
  .create()
  .then((client) => start(client))
  .catch((error) => {
    console.log(error);
  });

function start(client) {
  client.onMessage(async (message) => {
    if (message.body && message.isGroupMsg === false) {
      await axios.post('https://n8n-render-1-mp3q.onrender.com/webhook/8e82dffc-0e7c-40a2-b025-676ab1faa200', {
        mensaje: message.body,
        numero: message.from
      });
      await client.sendText(message.from, '✅ Recibí tu mensaje');
    }
  });
}
